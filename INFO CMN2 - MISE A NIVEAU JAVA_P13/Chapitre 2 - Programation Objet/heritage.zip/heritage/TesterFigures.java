package heritage;

public class TesterFigures {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceFormeGeometrique[] formes;
		formes = new InterfaceFormeGeometrique[3];
		
		formes[0] = new Cercle(5);
		formes[1] = new Rectangle(12, 5);
		formes[2] = new Carre(9);
		
		for(int i=0; i<3; i++)
			System.out.println("Je suis un " + formes[i].getClass().getSimpleName() + 
			", ma surface est: " + formes[i].surface() + " et mon p�rimetre est: " + 
					formes[i].perimetre());
	}

}
