package heritage;

public class Cercle implements InterfaceFormeGeometrique {
	private static final double PI = 3.14;
	private double rayon;
	
	
	public Cercle(double rayon) {
		super();
		this.rayon = rayon;
	}
	
	

	public double getRayon() {
		return rayon;
	}



	public void setRayon(double rayon) {
		this.rayon = rayon;
	}



	@Override
	public double perimetre() {
		// TODO Auto-generated method stub
		return 2 * PI * this.rayon;
	}

	@Override
	public double surface() {
		// TODO Auto-generated method stub
		return PI * this.rayon * this.rayon;
	}

}
