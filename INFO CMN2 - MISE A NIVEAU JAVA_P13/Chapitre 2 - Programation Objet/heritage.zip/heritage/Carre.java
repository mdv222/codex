package heritage;

public class Carre implements InterfaceFormeGeometrique {
	
	private float cote;
	
	

	public Carre(float cote) {
		super();
		this.cote = cote;
	}
	
	

	public float getCote() {
		return cote;
	}



	public void setCote(float cote) {
		this.cote = cote;
	}



	@Override
	public double perimetre() {
		// TODO Auto-generated method stub
		return 4 * this.cote;
	}

	@Override
	public double surface() {
		// TODO Auto-generated method stub
		return this.cote * this.cote;
	}



	

}
