package heritage;

public class TesterEtudiant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Etudiant etud1 = new Etudiant("Papa Alioune", "CISSE", "001");
		
		EtudiantBoursier etud2 = new EtudiantBoursier("Waidi", "BOBO", "002", 60000);

		etud1.afficher();
		etud2.afficher();
	}

}
