package heritage;

public interface InterfaceFormeGeometrique {
	public double perimetre();
	public double surface();
}
