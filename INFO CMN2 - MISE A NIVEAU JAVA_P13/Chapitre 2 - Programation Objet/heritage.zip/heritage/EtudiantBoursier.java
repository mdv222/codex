package heritage;

public class EtudiantBoursier extends Etudiant{
	private double bourse;
	
	public EtudiantBoursier(String prenom, String nom, String numero, double bourse) {
		super(prenom, nom, numero);
		this.bourse = bourse;	
	}

	public double getBourse() {
		return bourse;
	}

	public void setBourse(double bourse) {
		this.bourse = bourse;
	}

	public void afficher() {
		System.out.println("Pr�nom: " + this.getPrenom() + " Nom: " + this.getNom() + " Num�ro: " + this.getNumero() + " Bourse: " + this.bourse + " F CFA");
	}
	
	
	
}
