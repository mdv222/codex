package heritage;

public class Rectangle implements InterfaceFormeGeometrique {
	private float longueur;
	private float largeur;
		
	public Rectangle(float longueur, float largeur) {
		super();
		this.longueur = longueur;
		this.largeur = largeur;
	}

	@Override
	public double perimetre() {
		// TODO Auto-generated method stub
		return (this.largeur + this.longueur) * 2 ;
	}

	@Override
	public double surface() {
		// TODO Auto-generated method stub
		return this.longueur * this.largeur ;
	}

	public float getLongueur() {
		return longueur;
	}

	public void setLongueur(float longueur) {
		this.longueur = longueur;
	}

	public float getLargeur() {
		return largeur;
	}

	public void setLargeur(float largeur) {
		this.largeur = largeur;
	}
	
	

}
