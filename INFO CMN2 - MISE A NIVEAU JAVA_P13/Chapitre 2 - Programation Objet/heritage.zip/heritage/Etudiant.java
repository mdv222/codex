package heritage;

public class Etudiant {
	private String prenom;
	private String nom;
	private String numero;
	
	public Etudiant(String prenom, String nom, String numero) {
		super();
		this.prenom = prenom;
		this.nom = nom;
		this.numero = numero;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	public void afficher() {
		System.out.println("Pr�nom: " + this.prenom + " Nom: " + this.nom + " Num�ro: " + this.numero);
	}
	
}
