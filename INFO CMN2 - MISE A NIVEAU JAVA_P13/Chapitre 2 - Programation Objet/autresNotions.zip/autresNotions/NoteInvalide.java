package autresNotions;

public class NoteInvalide extends Exception{
	public NoteInvalide() {
		System.out.println("Erreur: la note doit �tre entre 0 et 20");
	}
}
