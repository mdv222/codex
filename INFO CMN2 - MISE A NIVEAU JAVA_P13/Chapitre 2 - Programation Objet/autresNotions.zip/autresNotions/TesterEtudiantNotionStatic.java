package autresNotions;

import java.util.Scanner;

public class TesterEtudiantNotionStatic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EtudiantNotionStatic etud1 = new EtudiantNotionStatic("Papa", "CISSE");
		
		EtudiantNotionStatic etud2 = new EtudiantNotionStatic("Moussa", "TRAORE", 10, 20, 0);
		
		EtudiantNotionStatic etud3 = new EtudiantNotionStatic("Fatou", "CAMARA");
		
		System.out.println("Il y a actuellement " + EtudiantNotionStatic.getNbEtudiant() + " �tudiants");
	}

}
