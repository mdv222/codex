package autresNotions;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TesterEtudiantNotionException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String prenom_, nom_, rep;
		float note1_, note2_;
		
		Scanner entree = new Scanner(System.in);
		
		do {
			System.out.println("Donner le pr�nom et le nom de l'�tudiant");
			prenom_ = entree.next();
			nom_ = entree.next();
			EtudiantNotionException etu = new EtudiantNotionException(prenom_, nom_);
			
			//Contr�le de saisie de la note 1 avec exception
			for(;;) {
				System.out.println("Donner la premi�re note de l'�tudiant");
				try {
					note1_ = entree.nextFloat(); 
					etu.setNote1(note1_);
					break;
				} catch(InputMismatchException ime) {
					entree.nextLine();
					System.out.println("Erreur: tapez une note valide");
				} catch(NoteInvalide ni) {
					
				}
			}
			
			//Contr�le de saisie de la note 2 avec exception
			for(;;) {
				System.out.println("Donner la deuxi�me note de l'�tudiant");
				try {
					note2_ = entree.nextFloat(); 
					etu.setNote2(note2_);
					break;
				} catch(InputMismatchException ime) {
					entree.nextLine();
					System.out.println("Erreur: tapez une note valide");
				} catch(NoteInvalide ni) {
					
				}
			}
			
			System.out.println("Voulez vous ajouter un autre �tudiant (o/n)?");
			rep = entree.next();
		} while(!rep.equals("n") & !rep.equals("N"));
		
		
		System.out.println("Il y a actuellement " + EtudiantNotionException.getNbEtudiant() + " �tudiants");
	}

}
