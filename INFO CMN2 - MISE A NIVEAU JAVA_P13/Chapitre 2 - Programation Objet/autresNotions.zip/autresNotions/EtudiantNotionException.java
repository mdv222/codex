package autresNotions;

public class EtudiantNotionException {
	private String prenom;
	private String nom;
	private float note1;
	private float note2;
	private float moyenne;
	private static int nbEtudiant = 0;
	public EtudiantNotionException(String prenom, String nom, float note1, float note2, float moyenne) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.note1 = note1;
		this.note2 = note2;
		this.moyenne = moyenne;
		
		EtudiantNotionException.nbEtudiant = EtudiantNotionException.nbEtudiant + 1;
		System.out.println("Je suis l'�tudiant n� " + EtudiantNotionException.nbEtudiant+ " � �tre instanci�");
	}
	public EtudiantNotionException(String prenom, String nom) {
		super();
		this.prenom = prenom;
		this.nom = nom;
		
		EtudiantNotionException.nbEtudiant = EtudiantNotionException.nbEtudiant + 1;
		System.out.println("Je suis l'�tudiant n� " + EtudiantNotionException.nbEtudiant+ " � �tre instanci�");
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public float getNote1() {
		return note1;
	}
	public void setNote1(float note1) throws NoteInvalide {
		if (note1 < 0 | note1 > 20)
			throw new NoteInvalide();
		else
			this.note1 = note1;
	}
	public float getNote2() {
		return note2;
	}
	public void setNote2(float note2) throws NoteInvalide {
		if (note2 < 0 | note2 > 20)
			throw new NoteInvalide();
		else
			this.note2 = note2;
	}
	public float getMoyenne() {
		return moyenne;
	}
	public void setMoyenne(float moyenne) {
		this.moyenne = moyenne;
	}
	public static int getNbEtudiant() {
		return nbEtudiant;
	}
	public static void setNbEtudiant(int nbEtudiant) {
		EtudiantNotionException.nbEtudiant = nbEtudiant;
	}
	
	public void claculerMoyenne() {
		this.moyenne = (this.note1 + this.note2) / (float)2;
	}
	
	@Override
	public String toString() {
		return "[prenom=" + prenom + ", nom=" + nom + ", note1=" + note1 + ", note2=" + note2
				+ ", moyenne=" + moyenne + "]";
	}	
	
	
}


