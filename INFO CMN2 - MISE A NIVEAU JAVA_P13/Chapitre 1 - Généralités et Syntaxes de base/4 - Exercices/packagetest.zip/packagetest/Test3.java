package packagetest;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 Ceci est un commentaire sur
		 plusieurs lignes;
		 ...
		 */
		int x = 8 ;
		System.out.println("La table de multiplication de " + x + " est: (boucle for)");
		for (int i = 1; i <= 12 ; i++) {
			System.out.println(x + " * " + i + " = " + (x*i));
		}
		System.out.println("-----------------------------------------------");
		
		int j = 1 ;
		int y = 5;
		System.out.println("La table de multiplication de " + y + " est: (boucle while...)");
		while (j < 13) {
			System.out.println(y + " * " + j + " = " + (y*j));
			j = j + 1 ; //équivaut à j++;
		}
		
		System.out.println("-----------------------------------------------");
		
		int k = 1 ;
		int z = 4;
		System.out.println("La table de multiplication de " + z + " est: (boucle do...while)");
		do {
			System.out.println(z + " * " + k + " = " + (z*k));
			k++ ;
		} while (k < 13);
	}

}
