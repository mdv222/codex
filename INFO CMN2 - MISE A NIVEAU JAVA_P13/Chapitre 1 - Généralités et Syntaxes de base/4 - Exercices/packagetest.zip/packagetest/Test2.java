package packagetest;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x ;
		int y ;
		int z ;
		
		char op;
		
		op = 'p';
		x = -25 ;
		y = -8 ;
		
		switch (op) {
		case '+': {
			z = x + y ;
			System.out.println(x + " + " + y + " = " + z);
			break;
		}
		case '-': {
			z = x - y ;
			System.out.println(x + " - " + y + " = " + z);
			break;
		}
		case '*': {
			z = x * y ;
			System.out.println(x + " * " + y + " = " + z);
			break;
		}
		case '/': {
			if (y == 0) {
				System.out.println("Division par zero impossible");
			} else {
				System.out.println(x + " / " + y + " = " + ((float)x/y));
			}
			break;
		}
		default:
			System.out.println("Opérateur inconnu");
		}
	}

}
