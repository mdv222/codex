package packagetest;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Bonjour tout le monde");
		int x ;
		int y ;
		int z ;
		
		x = -25 ;
		y = -8 ;
		z = x + y ;
		
		System.out.println(x + " + " + y + " = " + z);
		System.out.println(x + " - " + y + " = " + (x-y));
		System.out.println(x + " * " + y + " = " + (x*y));
		System.out.println(x + " / " + y + " = " + ((float)x/y));
		
		if (x > 0) {
			System.out.println(x + " est positif");
		} else{
			System.out.println(x + " est négatif");
		} 
		
		if (x < 0) {
			System.out.println(x + " est négatif");
		}else {
		if ((x >= 0) && (x <= 10)) {
			System.out.println(x + " est compris entre 0 (inclus) et 10 (inclus)");
		} else{
			if ((x > 10) && (x <= 20)){
			System.out.println(x + " est compris entre 10 et 2O (inclus)");
			} else {
				System.out.println(x + " est plus grand que 2O");
			}
		}
		}
		
		
	}

}
