package classesJava;

public class ClasseEtudiantsAvecLeursMoyennes {
	private String prenom;
	private String nom;
	private float note1;
	private float note2;
	private float moyenne;
	
	public ClasseEtudiantsAvecLeursMoyennes(String prenom, String nom, float note1, float note2, float moyenne) {
		super();
		this.prenom = prenom;
		this.nom = nom;
		this.note1 = note1;
		this.note2 = note2;
		this.moyenne = moyenne;
	}

	public ClasseEtudiantsAvecLeursMoyennes(String prenom, String nom) {
		super();
		this.prenom = prenom;
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public float getNote1() {
		return note1;
	}

	public void setNote1(float note1) {
		this.note1 = note1;
	}

	public float getNote2() {
		return note2;
	}

	public void setNote2(float note2) {
		this.note2 = note2;
	}

	public float getMoyenne() {
		return moyenne;
	}

	public void setMoyenne(float moyenne) {
		this.moyenne = moyenne;
	}
	
	public void calculerMoyenne() {
		this.moyenne = (this.note1 + this.note2) / 2;
	}

	@Override
	public String toString() {
		return "[Pr�nom=" + prenom + ", Nom=" + nom + ", note1=" + note1 + ", note2="
				+ note2 + ", moyenne=" + moyenne + "]";
	}
	
	
	
	
	
}
