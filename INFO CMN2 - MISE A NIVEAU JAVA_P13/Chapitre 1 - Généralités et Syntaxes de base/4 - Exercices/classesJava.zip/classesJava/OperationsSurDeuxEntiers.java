package classesJava;

public class OperationsSurDeuxEntiers {
	private int operande1;
	private String operateur;
	private int operande2;
	
	public OperationsSurDeuxEntiers() {
		super();
	}

	public OperationsSurDeuxEntiers(int operande1, String operateur, int operande2) {
		super();
		this.operande1 = operande1;
		this.operateur = operateur;
		this.operande2 = operande2;
	}

	public int getOperande1() {
		return operande1;
	}

	public void setOperande1(int operande1) {
		this.operande1 = operande1;
	}

	public String getOperateur() {
		return operateur;
	}

	public void setOperateur(String operateur) {
		this.operateur = operateur;
	}

	public int getOperande2() {
		return operande2;
	}

	public void setOperande2(int operande2) {
		this.operande2 = operande2;
	}
	
	public void effectuerOperation() {
		switch (operateur) {
		  case "+":
		    System.out.println(operande1 + " + " + operande2 + " = " + (operande1+operande2));
		    break;
		  case "-":
			  System.out.println(operande1 + " - " + operande2 + " = " + (operande1-operande2));
		    break;
		  case "*":
			  System.out.println(operande1 + " * " + operande2 + " = " + (operande1*operande2));
			  break;  
		  case "/":
			  if (operande2 == 0)
			    System.out.println("Division impossible");
			  else
				  System.out.println(operande1 + " / " + operande2 + " = " + (operande1/operande2));
			  break;
		  default:
			    System.out.println("Operateur inconnu");
			}
	}

	@Override
	public String toString() {
		return "OperationsSurDeuxEntiers [operande1= " + operande1 + ", operateur= " + operateur + ", operande2= "
				+ operande2 + "]";
	}
	
	
}
