package classesJava;

import java.util.Scanner;

public class TesterClasseEtudiantsAvecLeursMoyennes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClasseEtudiantsAvecLeursMoyennes[] classe;// = new ClasseEtudiantsAvecLeursMoyennes[3];
		
		String prenom_, nom_;
		float note1_, note2_;
		Scanner entree = new Scanner(System.in);
		
		int taille;
		
		System.out.println("Donner le nombre d'�tudiant");
		taille = entree.nextInt();
		
		classe = new ClasseEtudiantsAvecLeursMoyennes[taille];
		
		//Instanciation des �tudiants
		for(int i=0; i < taille; i++) {
			System.out.println("Donner le pr�nom, nom, note 1 et note 2 de l'�tudiant " + (i+1));
			prenom_ = entree.next();
			nom_ = entree.next();
			note1_ = entree.nextFloat();
			note2_ = entree.nextFloat();
			classe[i] = new ClasseEtudiantsAvecLeursMoyennes(prenom_, nom_, note1_, note2_, 0);
		}
		
		//Calcul des moyennes
		for(int i=0; i < taille; i++)
			classe[i].calculerMoyenne();
		
		//Affichage des �tudiants
				for(int i=0; i < taille; i++)
					System.out.println(classe[i]);
	}

}
