package classesJava;

public class TesterOperationsSurDeuxEntiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OperationsSurDeuxEntiers op1 = new OperationsSurDeuxEntiers();
		OperationsSurDeuxEntiers op2 = new OperationsSurDeuxEntiers(2, "+", 3);
		
		op2.effectuerOperation();		
		op2.setOperateur("*");
		op2.effectuerOperation();
		op2.setOperande2(0);
		op2.setOperateur("/");
		op2.effectuerOperation();
		op2.setOperateur("//");
		op2.effectuerOperation();
		
		System.out.println(op2);
	}

}
