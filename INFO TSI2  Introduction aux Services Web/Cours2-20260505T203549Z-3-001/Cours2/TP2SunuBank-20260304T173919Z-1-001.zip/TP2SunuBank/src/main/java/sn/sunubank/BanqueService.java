package sn.sunubank;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

/**
 * Interface du Web Service SunuBank.
 * Cette interface définit les méthodes accessibles aux clients SOAP.
 */
@WebService(name = "SunuBankWS")
public interface BanqueService {

    /**
     * Consulte le solde d'un compte.
     * @param code numéro du compte à vérifier
     * @return solde du compte
     */
    @WebMethod(operationName = "getSolde")
    double consulterSolde(@WebParam(name = "numeroCompte") String code);
}