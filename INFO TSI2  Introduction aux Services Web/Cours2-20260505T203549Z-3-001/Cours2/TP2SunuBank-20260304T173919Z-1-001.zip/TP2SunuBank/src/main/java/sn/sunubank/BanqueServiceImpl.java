package sn.sunubank;

import jakarta.jws.WebService;

/**
 * Implémentation du Web Service SunuBank.
 * Cette classe contient la logique métier du service bancaire.
 */
@WebService(endpointInterface = "sn.sunubank.BanqueService")
public class BanqueServiceImpl implements BanqueService {

    @Override
    public double consulterSolde(String code) {
        // Vérification de validité du numéro de compte
        if (code == null || code.isEmpty()) {
            System.out.println("Numéro de compte invalide !");
            return 0.0; // Retourne zéro pour éviter les erreurs
        }

        // Exemple de logique : comptes Orange Money commençant par 77
        if (code.startsWith("77")) {
            return 500000.0;
        }

        // Autres comptes
        return 150.0;
    }
}