package sn.sunubank;

import jakarta.xml.ws.Service;
import java.net.URL;
import javax.xml.namespace.QName;

public class TestSunuBankClient {

    public static void main(String[] args) throws Exception {

        // URL du WSDL exposé par le serveur
        URL wsdlURL = new URL("http://localhost:9091/sunubank?wsdl");

        // QName : namespace et nom du service générés automatiquement par JAX-WS
        QName SERVICE_NAME = new QName("http://sunubank.sn/", "BanqueServiceImplService");

        // Création du service avec le QName correct
        Service service = Service.create(wsdlURL, SERVICE_NAME);

        // Obtention du port pour invoquer les méthodes
        BanqueService port = service.getPort(BanqueService.class);

        // Test de la méthode
        String numeroCompte = "771234567";
        double solde = port.consulterSolde(numeroCompte);

        System.out.println("Solde du compte " + numeroCompte + " = " + solde);



    }
}