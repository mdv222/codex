package sn.sunubank;

import jakarta.xml.ws.Endpoint;

/**
 * Classe principale pour démarrer le serveur SOAP.
 * Publie le service SunuBank sur l'URL spécifiée.
 */
public class SunuBankServer {

    public static void main(String[] args) {
        // URL où le service sera accessible
        String url = "http://localhost:9091/sunubank";

        // Publication du service
        Endpoint.publish(url, new BanqueServiceImpl());

        System.out.println("Banque SunuBank opérationnelle sur : " + url + "?wsdl");
    }
}