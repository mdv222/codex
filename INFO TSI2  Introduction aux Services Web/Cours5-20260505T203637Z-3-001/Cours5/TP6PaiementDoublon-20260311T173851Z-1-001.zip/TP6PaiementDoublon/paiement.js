const express = require('express');
const crypto = require('crypto');
const app = express();

app.use(express.json({
    verify: (req, res, buf) => { req.rawBody = buf.toString(); }
}));

const SECRET_WEBHOOK = "CLE_SECURE_SENEGAL_2024";

// --- SIMULATION D'UNE BASE DE DONNÉES ---
// En vrai, on utiliserait MySQL ou MongoDB
const transactionsTraitees = new Set(); 

app.post('/webhook/paiement-termine', (req, res) => {
    const signatureFournisseur = req.headers['x-pay-signature'];
    const hashLocal = crypto.createHmac('sha256', SECRET_WEBHOOK)
                             .update(req.rawBody)
                             .digest('hex');

    if (hashLocal !== signatureFournisseur) {
        return res.status(401).send('Signature invalide');
    }

    const { reference, montant } = req.body;

    // --- VÉRIFICATION DU DOUBLON ---
    if (transactionsTraitees.has(reference)) {
        console.log(`⚠️ DOUBLON DÉTECTÉ : La transaction ${reference} a déjà été traitée.`);
        
        // IMPORTANT : On renvoie quand même 200 OK au fournisseur 
        // pour qu'il arrête d'envoyer cette notification.
        return res.status(200).send('Déjà traité');
    }

    // --- TRAITEMENT NORMAL ---
    console.log(`✅ PREMIER TRAITEMENT : Validation de ${montant} FCFA (Ref: ${reference})`);
    
    // On ajoute la référence à notre "liste noire" de transactions terminées
    transactionsTraitees.add(reference);

    res.status(200).send('Paiement validé avec succès');
});

app.listen(4000, () => console.log("Serveur anti-doublon actif sur le port 4000"));