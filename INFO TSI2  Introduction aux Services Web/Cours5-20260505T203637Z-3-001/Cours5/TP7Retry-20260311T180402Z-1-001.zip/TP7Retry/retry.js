/**
 * Fonction de Retry avec "Exponential Backoff"
 * @param {string} url - L'adresse à interroger
 * @param {number} maxRetries - Nombre d'essais maximum (par défaut 3)
 */
async function appelerApiAvecRetry(url, maxRetries = 3) {
    let attente = 1000; // Point de départ : 1 seconde

    for (let i = 0; i < maxRetries; i++) {
        try {
            console.log(`🔄 Tentative ${i + 1}/${maxRetries} pour : ${url}...`);

            // On lance la requête
            const response = await fetch(url);

            // Fetch ne "catch" pas les erreurs 404 ou 500, 
            // il faut donc vérifier manuellement si la réponse est OK.
            if (!response.ok) {
                throw new Error(`Erreur HTTP : ${response.status}`);
            }

            const data = await response.json();
            console.log("✅ Succès ! Données reçues.");
            return data;

        } catch (err) {
            // Si on a atteint le dernier essai, on arrête de boucler et on transmet l'erreur
            if (i === maxRetries - 1) {
                console.error("❌ Abandon : Tous les essais ont échoué.");
                throw err;
            }

            // Stratégie de Retry :
            console.log(`⚠️ Échec (${err.message}). Réessai dans ${attente / 1000}s...`);
            
            // On attend avant de recommencer
            await new Promise(res => setTimeout(res, attente));
            
            // On double le temps pour la prochaine fois (1s -> 2s -> 4s...)
            attente *= 2; 
        }
    }
}

// --- ZONE DE TEST ---
// On utilise une URL qui n'existe pas pour forcer l'échec et voir le retry en action
const URL_TEST = "https://jsonplaceholder.typicode.com/posts/1"; // URL valide
const URL_ERREUR = "https://cette-url-n-existe-pas-123.com";      // URL invalide

appelerApiAvecRetry(URL_ERREUR)
    .then(data => console.log("Résultat final :", data))
    .catch(err => console.log("Fin du script après erreur fatale."));