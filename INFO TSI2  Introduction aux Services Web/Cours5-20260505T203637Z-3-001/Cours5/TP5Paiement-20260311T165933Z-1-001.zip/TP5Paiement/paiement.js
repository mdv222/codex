const express = require('express');
const crypto = require('crypto');

const app = express();

// Utilisation d'un middleware pour capturer le corps brut (raw body)
// C'est indispensable car JSON.stringify peut modifier l'ordre des champs
// et faire échouer la vérification de la signature.
app.use(express.json({
    verify: (req, res, buf) => {
        req.rawBody = buf.toString();
    }
}));

const SECRET_WEBHOOK = "CLE_SECURE_SENEGAL_2024";

/**
 * Route Webhook : C'est l'URL que le partenaire de paiement appelle
 * pour nous dire "Hé, le client a payé !".
 */
app.post('/webhook/paiement-termine', (req, res) => {
    
    // A. RÉCUPÉRATION : On récupère la signature envoyée par le fournisseur
    const signatureFournisseur = req.headers['x-pay-signature'];

    if (!signatureFournisseur) {
        return res.status(400).send("Signature manquante");
    }

    // B. CALCUL : On recrée la signature de notre côté avec notre clé secrète
    // On utilise req.rawBody pour être certain d'avoir exactement les mêmes caractères
    const hashLocal = crypto.createHmac('sha256', SECRET_WEBHOOK)
                             .update(req.rawBody)
                             .digest('hex');

    // C. COMPARAISON : On compare les deux signatures
    // Si elles sont identiques, c'est que le message vient bien du fournisseur
    if (hashLocal === signatureFournisseur) {
        
        // Les données sont validées, on peut extraire les infos
        const { montant, client, reference } = req.body;
        
        console.log(`✅ SUCCÈS : Paiement de ${montant} FCFA reçu.`);
        console.log(`Client : ${client} | Référence : ${reference}`);

        // --- ICI : Mettre à jour votre base de données ---
        // Ex: await Commande.update({ statut: 'payé' }, { where: { ref: reference } });

        // On répond 200 (OK) pour dire au fournisseur de ne plus nous renvoyer d'alertes
        res.status(200).send('Notification reçue et validée !');

    } else {
        // D. SÉCURITÉ : Les signatures ne correspondent pas
        console.error("🚨 ALERTE : Tentative de fraude ou erreur de clé !");
        
        // On répond 401 (Non autorisé)
        res.status(401).send('Signature invalide');
    }
});

const PORT = 4000;
app.listen(PORT, () => {
    console.log(`🚀 Serveur en écoute sur http://localhost:${PORT}`);
    console.log(`Point d'entrée Webhook : http://localhost:${PORT}/webhook/paiement-termine`);
});