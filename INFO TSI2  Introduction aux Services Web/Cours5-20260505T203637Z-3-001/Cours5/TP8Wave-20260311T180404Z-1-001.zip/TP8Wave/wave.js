const express = require('express');
const crypto = require('crypto'); 
// axios permet de faire des requêtes HTTP vers d'autres serveurs (comme l'API Orange)
const axios = require('axios');   

const app = express();

/**
 * MIDDLEWARE CRUCIAL : Capture du corps brut (Raw Body)
 * Pour vérifier une signature HMAC, on doit travailler sur le texte EXACT
 * envoyé par Wave, avant que Express ne le transforme en objet JavaScript.
 */
app.use(express.json({
    verify: (req, res, buf) => {
        req.rawBody = buf.toString();
    }
}));

const PORT = 4000;

// Configuration (En production, utilisez un fichier .env)
const WAVE_WEBHOOK_SECRET = "CLE_SECRET_WAVE_SN_2026"; 
const ORANGE_SMS_TOKEN = "TOKEN_API_ORANGE_SECRET";

// --- BASE DE DONNÉES SIMULÉE ---
// On imagine qu'une commande CMD-101 existe déjà, créée lors du clic sur "Acheter"
let inscriptions = [
    { id: "CMD-101", nom: "Moussa Diop", tel: "771234567", status: "EN_ATTENTE" }
];

/**
 * 1. LE WEBHOOK DE PAIEMENT
 * Cette route attend que Wave lui dise : "Le paiement est fait !"
 */
app.post('/webhooks/paiement', async (req, res) => {
    console.log("\n🔔 Notification de paiement reçue de Wave...");

    // A. SÉCURITÉ : Est-ce bien Wave qui m'envoie ce message ?
    const signatureRecue = req.headers['x-wave-signature'];

    // On recalcule la signature avec notre clé secrète et le corps brut
    const signatureAttendue = crypto
        .createHmac('sha256', WAVE_WEBHOOK_SECRET)
        .update(req.rawBody) // Utilisation du rawBody pour la précision
        .digest('hex');

    if (signatureRecue !== signatureAttendue) {
        console.error("❌ ALERTE : Signature invalide ! Accès refusé.");
        return res.status(401).send("Non autorisé");
    }

    // B. LOGIQUE MÉTIER : Si la signature est OK, on traite la donnée
    const { id_commande, status, montant } = req.body;

    if (status === "SUCCESS") {
        console.log(`💰 Paiement de ${montant} FCFA confirmé pour ${id_commande}`);

        // On cherche la commande dans notre "base de données"
        const index = inscriptions.findIndex(i => i.id === id_commande);
        
        if (index !== -1) {
            // Mise à jour de l'état
            inscriptions[index].status = "VALIDÉ";
            console.log(`📝 Statut mis à jour pour : ${inscriptions[index].nom}`);

            // C. DÉCLENCHEMENT DE L'ACTION SUIVANTE : Envoi du SMS
            // On ne bloque pas la réponse à Wave, on lance le SMS en parallèle
            const clientTel = inscriptions[index].tel;
            const clientNom = inscriptions[index].nom;
            
            // On appelle la fonction SMS (définie plus bas)
            await envoyerSmsConfirmation(clientTel, clientNom);
        } else {
            console.log("⚠️ Commande introuvable dans la base.");
        }
    }

    // D. ACCUSÉ DE RÉCEPTION : On dit à Wave qu'on a bien reçu l'info
    res.status(200).send("OK");
});

/**
 * 2. FONCTION D'ENVOI SMS
 * Simule un appel à la passerelle Orange ou InTouch
 */
async function envoyerSmsConfirmation(telephone, nom) {
    console.log(`✉️ Préparation du message pour le ${telephone}...`);
    
    const message = `Félicitations ${nom}, votre inscription sur SunuBank est validée !`;

    try {
        // Dans un cas réel, on ferait ceci :
        /*
        await axios.post('https://api.orange.com/sms/v1/send', {
            to: telephone,
            body: message
        }, {
            headers: { 'Authorization': `Bearer ${ORANGE_SMS_TOKEN}` }
        });
        */
        
        console.log(`🚀 SMS ENVOYÉ avec succès : [${message}]`);
        return true;
    } catch (error) {
        console.error("❌ Erreur API SMS Orange :", error.message);
    }
}

app.listen(PORT, () => {
    console.log(`🚀 Serveur Marchand prêt sur http://localhost:${PORT}`);
    console.log(`📍 URL Webhook à tester : http://localhost:${PORT}/webhooks/paiement`);
});