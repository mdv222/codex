/**
 * =========================================================
 *  SERVER.JS - Gestion des pharmacies (CRUD) avec Express
 * =========================================================
 *
 * Ce serveur simule une API REST pour gérer des pharmacies à Dakar.
 * Il inclut les opérations CRUD : Create, Read, Update, Delete.
 * Les données sont stockées en mémoire (simulation de base de données).
 */

/**
 * 1️⃣ IMPORTATION DES MODULES
 * Express est un framework léger pour créer des serveurs web en Node.js.
 */
const express = require('express'); // Import du framework
const app = express();              // Création de l'application Express
const PORT = 4000;                  // Port sur lequel le serveur sera accessible

// Middleware pour parser le JSON dans les requêtes entrantes
// Sans ça, req.body serait undefined pour les POST/PUT
app.use(express.json());

/**
 * 2️⃣ BASE DE DONNÉES SIMULÉE (EN MÉMOIRE)
 * Ici, nous utilisons un tableau d'objets pour représenter nos pharmacies.
 * Chaque objet contient :
 *   - id       : identifiant unique
 *   - nom      : nom de la pharmacie
 *   - ville    : ville où se trouve la pharmacie
 *   - quartier : quartier de la pharmacie
 *   - garde    : true si la pharmacie est de garde, false sinon
 */
let pharmacies = [
    { id: 1, nom: "Pharmacie de la Nation", ville: "Dakar", quartier: "Plateau", garde: true },
    { id: 2, nom: "Pharmacie Serigne Fallou", ville: "Touba", quartier: "Darou Marnane", garde: false },
    { id: 3, nom: "Pharmacie Cheikh Anta Diop", ville: "Dakar", quartier: "Fann", garde: true }
];

/**
 * =========================================================
 *  3️⃣ OPÉRATIONS CRUD
 * =========================================================
 */

/**
 * 3.1️⃣ LIRE (READ) - Liste des pharmacies
 * - URL : GET /pharmacies
 * - Possibilité de filtrer via query params : ?ville=Dakar&garde=true
 */
app.get('/pharmacies', (req, res) => {
    // Copie du tableau original pour éviter de modifier la base
    let resultat = [...pharmacies];

    // Récupération des filtres depuis l'URL
    const { ville, garde } = req.query;

    // Filtrage par ville si fourni
    if (ville) {
        resultat = resultat.filter(p => p.ville.toLowerCase() === ville.toLowerCase());
    }

    // Filtrage par garde si fourni
    if (garde) {
        // Conversion de la chaîne "true"/"false" en booléen
        const isGarde = (garde === 'true');
        resultat = resultat.filter(p => p.garde === isGarde);
    }

    // Envoi de la réponse JSON avec code 200 OK
    res.status(200).json(resultat);
});

/**
 * 3.2️⃣ CRÉER (CREATE) - Ajouter une nouvelle pharmacie
 * - URL : POST /pharmacies
 * - Corps de la requête JSON attendu : { nom, ville, quartier, garde }
 */
app.post('/pharmacies', (req, res) => {
    const nouvellePharma = {
        id: pharmacies.length + 1,      // ID automatique incrémenté
        nom: req.body.nom,
        ville: req.body.ville,
        quartier: req.body.quartier,
        garde: req.body.garde || false  // Par défaut, garde = false si non fourni
    };

    // Validation simple (simule les règles d'un XSD ou d'un schéma)
    if (!nouvellePharma.nom || !nouvellePharma.ville) {
        return res.status(400).json({ erreur: "Le nom et la ville sont obligatoires !" });
    }

    // Ajout de la nouvelle pharmacie dans la "base"
    pharmacies.push(nouvellePharma);

    // 201 Created : création réussie
    res.status(201).json(nouvellePharma);
});

/**
 * 3.3️⃣ METTRE À JOUR (UPDATE) - Modifier une pharmacie existante
 * - URL : PUT /pharmacies/:id
 * - Exemple : PUT /pharmacies/1
 */
app.put('/pharmacies/:id', (req, res) => {
    const id = parseInt(req.params.id);               // Récupération de l'id depuis l'URL
    const index = pharmacies.findIndex(p => p.id === id); // Cherche la pharmacie

    if (index !== -1) {
        // Mise à jour des champs fournis dans le corps de la requête
        pharmacies[index] = { ...pharmacies[index], ...req.body };
        res.status(200).json({ message: "Pharmacie mise à jour", data: pharmacies[index] });
    } else {
        // 404 Not Found si l'ID n'existe pas
        res.status(404).json({ erreur: "Pharmacie introuvable" });
    }
});

/**
 * 3.4️⃣ SUPPRIMER (DELETE) - Retirer une pharmacie
 * - URL : DELETE /pharmacies/:id
 */
app.delete('/pharmacies/:id', (req, res) => {
    const id = parseInt(req.params.id);           // Récupération de l'id
    pharmacies = pharmacies.filter(p => p.id !== id); // Suppression de la pharmacie

    // 204 No Content : succès, mais pas de contenu à renvoyer
    res.status(204).send();
});

/**
 * =========================================================
 *  4️⃣ LANCEMENT DU SERVEUR
 * =========================================================
 */
app.listen(PORT, () => {
    console.log(`Serveur Dakar-Pharma lancé sur http://localhost:${PORT}`);
    console.log("Prêt pour les tests Postman !");
});