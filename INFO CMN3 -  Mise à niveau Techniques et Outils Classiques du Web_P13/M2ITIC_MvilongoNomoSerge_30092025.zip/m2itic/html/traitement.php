<?php

/** Liste des champs attendus pour le controle. */
$required_fields = [
    'civilite',
    'nom',
    'prenom',
    'date_naissance',
    'commune_naissance',
    'liste_communes',
    'telephone',
    'courriel',
    'site_web',
    'niveau_anglais',
    'langages'
];

/** Variable pour les messages d'erreurs */
$errors = [];

/**
 * On vérifie que tous les champs sont remplis en parcourant toutes les variables POST
 */
foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        $errors[] = "Le champ $field est requis.";
    }
}

/** Calcul de l'âge. */
if (empty($errors)) {
    $date_naissance = $_POST['date_naissance'];
    /** On découpe la chaîne de la date de naissance pour extraire le jour, le mois et l'année. */
    $date_parts = explode('/', $date_naissance);
    /** Controle sur le format de la date */
    if (count($date_parts) === 3) {
        /** Nous allons assigner les variables par ordre du tableau $date_parts */
        list($jour, $mois, $annee) = $date_parts;
        /** Vérification de la date */
        if (checkdate((int)$mois, (int)$jour, (int)$annee)) {
            $date_naissance_obj = DateTime::createFromFormat('d/m/Y', $date_naissance);
            $now = new DateTime();
            /** Différence d'année entre l'année de naissance et celle actuelle. */
            $age = $now->diff($date_naissance_obj)->y;
            echo "<p>Âge calculé : $age ans</p>";
        } else {
            $errors[] = "La date de naissance n'est pas valide.";
        }
    } else {
        $errors[] = "Le format de la date de naissance doit être jj/mm/aaaa.";
    }
}

/** Affichage de la liste des erreurs */
if (!empty($errors)) {
    foreach ($errors as $error) {
        echo "<p>$error</p>";
    }
} else {
    echo "<p>Tous les champs sont valides.</p>";
}
