<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COURS M2ITIC - HTML / PHP </title>
</head>

<body>
    <h1>Bienvenue sur le site de COURS M2ITIC - HTML / PHP</h1>
    <ul>
        <li><a href="age.html" target="_blank">Formulaire d'âge en Html/JavaScript</a></li>
        <li><a href="age.php" target="_blank">Formulaire d'âge en PHP</a></li>
        <li><a href="tableau.html" target="_blank">Exemple de tableau</a></li>
        <li><a href="infos_personnelles.html" target="_blank">Infos. personnelles</a></li>
    </ul>
</body>

</html>