<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COURS M2ITIC - HTML / PHP </title>
</head>

<body>
    <h1>Formulaire d'âge en PHP</h1>
    <?php
    $age = null;
    $message = "";

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['age']) && trim($_POST['age']) !== "" && is_numeric($_POST['age'])) {
            $age = (int)$_POST['age'];
            if ($age >= 6 && $age <= 7) {
                $message = "Poussin.";
            } elseif ($age >= 8 && $age <= 9) {
                $message = "Pupile.";
            } elseif ($age >= 10 && $age <= 11) {
                $message = "Minime.";
            } elseif ($age >= 12 && $age <= 17) {
                $message = "Cadet.";
            } elseif ($age > 17) {
                $message = "Vous êtes un senior.";
            }
        } else {
            $message = "Veuillez entrer un âge valide.";
        }
    }
    ?>

    <form method="post" action="age.php">
        <label for="age">Quel est votre âge ?</label>
        <input type="text" name="age" id="age" value="<?php echo htmlspecialchars($age ?? ''); ?>">
        <button type="submit">Valider</button>
    </form>

    <?php if ($message): ?>
        <p><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>
</body>

</html>